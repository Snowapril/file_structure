//�й�: 201624506
//�̸�: ����ȫ
//github id: Snowapril

#include "Student.h"
#include "CourseRegistration.h"
#include "buffile.h"
#include "length.h"
#include "delim.h"
#include "fixfld.h"

template <typename RecordType, typename BufferType>
void TestBufferFile(BufferType Buff)
{
	RecordType::InitBuffer(Buff);
	RecordType record;
	RecordType* stable[10];
	int count, select;
	int result;
	int recaddr = -1;
	std::string filename;
	cout << "Enter the file name:" << flush; cin >> filename;

	bool bQuit = false;
	while (!bQuit)
	{
		cout << "\nSelect command 1: record input, 2. display, 3. write to file, 4. read from file, 5: Quit => ";
		cin >> select;

		switch (select) {
		case 1:
			//to store a array of Record objects by inputing
			cout << "the number of object records : ";
			cin >> count;
			cin.clear();
			cin.ignore(INT_MAX, '\n');
			for (int i = 0; i < count; i++)
			{
				cin >> record;
				record.Print(cout);
				stable[i] = new RecordType(record); // copy constructor should be implemented			}
			}
			break;
		case 2:
			// to display the array of objects into screen  
			for (int i = 0; i < count; i++)
			{
				cout << (*stable[i]); // operator<< (operator overloading) should be implemented
			}
			break;
		case 3:
		{
			// to write the array of objects into a file
			BufferFile TestOut(Buff);
			result = TestOut.Create(filename.c_str(), ios::in | ios::out);
			cout << "create file " << result << endl;
			if (!result)
			{
				cout << "Unable to create file " << filename << endl;
			}

			for (int i = 0; i < count; i++)
			{
				stable[i]->Print(cout);
				stable[i]->Pack(Buff);
				delete(stable[i]); //return the object created by new()
			}
			recaddr = TestOut.Write();
			if (recaddr == -1) cout << "Failed to write records" << endl;
			else cout << "Write records num " << count << " at address " << recaddr << endl;
			break;
		}
		case 4:
		{
			// to read the array of records from the file
			BufferFile TestIn(Buff);
			result = TestIn.Open(filename.c_str(), ios::in);
			if (!result)
			{
				cout << "Unable to read file " << filename << endl;
			}
			recaddr = TestIn.Read();
			if (recaddr == -1) cout << "Failed to read records" << endl;
			else cout << "Read records num " << count << " at address " << recaddr << endl;

			for (int i = 0; i < count; i++)
			{
				stable[i] = new RecordType();
				stable[i]->Unpack(Buff);
				stable[i]->Print(cout);
			}

			break;
		}
		default:
			bQuit = true;
			break;
		}
	}
}

int main(int argc, char ** argv)
{
	cout << "\nTesting LengthFieldBuffer with Student Record" << endl;
	TestBufferFile<Student>(LengthFieldBuffer());
	
	cout << "\nTesting FixedFieldBuffer with Student Record" << endl;
	TestBufferFile<Student>(FixedFieldBuffer(5));
	
	cout << "\nTesting DelimFieldBuffer with Student Record" << endl;
	TestBufferFile<Student>(DelimFieldBuffer('|'));

	cout << "\nTesting LengthFieldBuffer with CourseRegistration Record" << endl;
	TestBufferFile<CourseRegistration>(LengthFieldBuffer());

	cout << "\nTesting FixedFieldBuffer with CourseRegistration Record" << endl;
	TestBufferFile<CourseRegistration>(FixedFieldBuffer(5));

	cout << "\nTesting DelimFieldBuffer with CourseRegistration Record" << endl;
	TestBufferFile<CourseRegistration>(DelimFieldBuffer());

	return 1;
}
